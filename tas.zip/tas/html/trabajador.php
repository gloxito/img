<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/trabajador.css">
	<link rel="icon" href="../assets/T.ico" type="image/png">
    <title>Iniciar/Registro</title>
</head>
<body>
    
<div class="container" id="container">
	<div class="form-container sign-up-container">
		
		
	</div>
	<div class="form-container sign-in-container">
		<form action="../php/trabajadores/acceso_trabajador.php" method="POST">
			<h1>Iniciar sesión</h1>
			<input type="email" name="email" placeholder="Correo Electronico" required />
			<input type="password" name="password" placeholder="Contraseña" required />
			<button type="submit" name="login">Iniciar sesión</button>
			<a href="../php/landing.php" class="">Regresar</a>
		</form>
		
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-right">
				<h1>Bienvenido a TAS</h1>
				<p>Inicia sesión para acceder a tu portal :D</p>
                <img src="../assets/admin.png" alt="" style="width: 150px; height: auto; margin-top: 10px;">
			</div>
		</div>
	</div>
</div>
<script src="../js/trabajador.js"></script>
</body>
</html>