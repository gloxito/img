<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/ybtva-ertvfgre.css">
	<link rel="icon" href="../assets/T.ico" type="image/png">
    <title>Iniciar/Registro</title>
</head>
<body>
    
<div class="container" id="container">
	<div class="form-container sign-up-container">
		<form action="../php/usuarios/registro.php" method="POST">
			<h1>Registrate</h1>
			<input type="text" name="nombre" placeholder="Nombre" required />
			<input type="text" name="apellido" placeholder="Apellido" required />
			<input type="email" name="email" placeholder="Correo Electrónico" required />
			<input type="password" name="password" placeholder="Contraseña" required />
			<button type="submit">Registrarse</button>
			<a href="../php/landing.php" class="">Regresar</a>
		</form>		
		
	</div>
	<div class="form-container sign-in-container">
		<form action="../php/usuarios/acceso.php" method="POST">
			<h1>Iniciar sesión</h1>
			<input type="email" name="email" placeholder="Correo Electronico" required />
			<input type="password" name="password" placeholder="Contraseña" required />
			<button type="submit" name="login">Iniciar sesión</button>
			<a href="../php/landing.php" class="">Regresar</a>
		</form>
		
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>¿Tienes cuenta?</h1>
				<p>Inicia sesion para acceder a tu portal :D</p>
				<button class="ghost" id="signIn">Entrar</button>
			</div>
			<div class="overlay-panel overlay-right">
				<h1>¿Nuevo por aqui?</h1>
				<p>Ingresa tus datos y comienza tu viaje con nosotros :D</p>
				<button class="ghost" id="signUp">Registrate</button>
			</div>
		</div>
	</div>
</div>
<script src="../js/ybtva-ertvfgre.js"></script>
</body>
</html>