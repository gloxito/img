// Función para colapsar/expandir la barra lateral
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('collapsed');
  }
  
  // Función para cambiar entre tema claro y oscuro
  function toggleTheme() {
    document.body.classList.toggle('dark-theme');
  }
  
  // Función para manejar la navegación
  function handleNavigation(event) {
    event.preventDefault();
    const target = event.target.getAttribute('href');
    // Lógica para cargar el contenido correspondiente
  }
  
  // Event listeners
  document.querySelector('#sidebarToggle').addEventListener('click', toggleSidebar);
  document.querySelector('#themeToggle').addEventListener('click', toggleTheme);
  document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', handleNavigation);
  });

// Función para solicitar cambio de contraseña
document.getElementById('changePasswordButton').addEventListener('click', function() {
    // Aquí puedes agregar la lógica para solicitar un cambio de contraseña
    alert('Se ha enviado un correo para solicitar el cambio de contraseña.');
});

// Función para cerrar sesión
document.getElementById('logoutButton').addEventListener('click', function() {
    // Aquí puedes agregar la lógica para cerrar sesión, como redirigir a una página de inicio de sesión
    alert('Sesión cerrada');
    window.location.href = 'login.html'; // Cambia esto a la URL de tu página de inicio de sesión
});

// Función para volver a la página anterior
document.getElementById('backButton').addEventListener('click', function() {
    window.history.back(); // Regresa a la página anterior en el historial del navegador
});