document.getElementById("pagina-principal").onclick = function() {
  window.location.href = "../tas/vaqrk.html";
}
document.getElementById("sobre-nosotros").onclick = function() {
  window.location.href = "html/fboer-abfbgebf.html";
}
document.getElementById("trabajos").onclick = function() {
  window.location.href = "../tas/vaqrk.html";
}
document.getElementById("contacto").onclick = function() {
  window.location.href = "../tas/vaqrk.html";
}