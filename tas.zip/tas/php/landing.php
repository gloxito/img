<?php
session_start(); // Iniciar la sesión

// Si el usuario está logueado, redirigir al dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: ./usuarios/user_dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAs - Gestor de Tickets Avanzado</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap">
    <link rel="stylesheet" href="../css/landing.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <nav class="navbar">
        <div class="navbar-container">
            <div class="logo">
                <svg class="logo-icon" viewBox="0 0 24 24">
                    <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/>
                </svg>
                <span class="logo-text">TAS</span>
            </div>
            <ul class="nav-menu">
                <li class="nav-item"><a href="#features" class="nav-link">Características</a></li>
                <li class="nav-item"><a href="#about-us" class="nav-link">About us</a></li>
                <li class="nav-item"><a href="#testimonials" class="nav-link">Testimonios</a></li>
                <li class="nav-item"><a href="#contact" class="nav-link">Contacto</a></li>
            </ul>
            <div class="cta-buttons">
                <button class="cta-button" id="login-button" onclick="location.href='../html/ybtva-ertvfgre.php'">Iniciar Sesión</button>
                <button class="cta-button" id="signup-button" onclick="location.href='../html/ybtva-ertvfgre.php'">Prueba Gratuita</button>
            </div>

    
            <div class="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </nav>
    <main>
        <section id="hero">
            <div class="hero-content">
                <h1>Gestión de Tickets Simplificada</h1>
                <p>Optimiza tu soporte al cliente con TAS: la solución integral para equipos modernos</p>
                <button class="cta-button">Comienza tu prueba de 14 días</button>
            </div>
            <div class="hero-image">
                <img src="../assets/tas-landing.jpg" alt="TAS Dashboard">
            </div>
        </section>

        <section id="stats">
            <div class="stat">
                <span class="stat-value" data-value="1000">0</span>
                <span class="stat-label">Clientes Satisfechos</span>
            </div>
            <div class="stat">
                <span class="stat-value" data-value="5000000">0</span>
                <span class="stat-label">Tickets Resueltos</span>
            </div>
            <div class="stat">
                <span class="stat-value" data-value="99">0</span>
                <span class="stat-label">% de Satisfacción</span>
            </div>
        </section>

        <section id="features">
            <h2>Características Principales</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <i class="fas fa-robot"></i>
                    <h3>Automatización IA</h3>
                    <p>Resuelve tickets rutinarios automáticamente</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-chart-line"></i>
                    <h3>Análisis en Tiempo Real</h3>
                    <p>Toma decisiones basadas en datos actualizados</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-comments"></i>
                    <h3>Omnicanal</h3>
                    <p>Gestiona todos tus canales desde un solo lugar</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-user-shield"></i>
                    <h3>Seguridad Avanzada</h3>
                    <p>Protege los datos de tus clientes con encriptación de nivel militar</p>
                </div>
            </div>
        </section>

        <section id="about-us">
            <div class="container">
                <h2>Sobre Nosotros</h2>
                <p>En TAs, nos enorgullece contar con un equipo de expertos dedicados a revolucionar la gestión de tickets y la atención al cliente:</p>
                <div class="team-members">
                    <div class="team-member">
                        <img src="../assets/bea.jpg" alt="Beatriz Suarez">
                        <h3>Beatriz Suarez</h3>
                        <p>CEO y Visionaria</p>
                        <p>Más de 15 años de experiencia en tecnología y servicio al cliente.</p>
                    </div>
                    <div class="team-member">
                        <img src="../assets/leo.jpg" alt="Leonardo Duarte">
                        <h3>Leonardo Duarte</h3>
                        <p>Director de Tecnología</p>
                        <p>Responsable de nuestras innovadoras soluciones de software.</p>
                    </div>
                    <div class="team-member">
                        <img src="../assets/monti.jpg" alt="Mark Mountoto">
                        <h3>Marc Mountouto</h3>
                        <p>Jefe de Experiencia del Cliente</p>
                        <p>Asegura que cada interacción con TAs sea excepcional.</p>
                    </div>
                </div>
            </div>
        </section>
        

        <section id="testimonials">
            <h2>Lo que dicen nuestros clientes</h2>
            <div class="testimonial-carousel">
                <div class="testimonial">
                    <p>"TAS ha transformado nuestra atención al cliente. Es intuitivo y potente."</p>
                    <cite>- María González, CEO de TechSolutions</cite>
                </div>
                <div class="testimonial">
                    <p>"Desde que implementamos TAS, nuestro tiempo de respuesta se redujo en un 60%."</p>
                    <cite>- Carlos Rodríguez, Gerente de Soporte en MegaCorp</cite>
                </div>
                <div class="testimonial">
                    <p>"La integración omnicanal de TAS nos permite estar siempre conectados con nuestros clientes."</p>
                    <cite>- Ana Martínez, Directora de Experiencia de Cliente en GlobalRetail</cite>
                </div>
            </div>
        </section>
                <div class="contact-info">
                    <p>Contáctanos hoy y da el primer paso hacia una atención al cliente superior.</p>
                    <ul>
                        <li><i class="fas fa-phone"></i> +1 (555) 123-4567</li>
                        <li><i class="fas fa-envelope"></i> info@tas-system.com</li>
                    </ul>
                </div>
                <form id="contact-form">
                    <input type="text" name="name" placeholder="Tu nombre" required>
                    <input type="email" name="email" placeholder="Tu email" required>
                    <textarea name="message" placeholder="Tu mensaje" required></textarea>
                    <button type="submit" class="cta-button">Enviar Mensaje</button>
                </form>
            </div>
        </section>

        <section id="cta">
            <h2>Potencia tu Servicio al Cliente Hoy</h2>
            <p>Únete a miles de empresas que confían en TAS</p>
            <button class="cta-button">Iniciar Prueba Gratuita</button>
        </section>
    </main>

    <footer>
        <div class="footer-content">
            <svg class="logo-icon" viewBox="0 0 24 24">
                    <path d="M19.5 3h-15A1.5 1.5 0 003 4.5v15A1.5 1.5 0 004.5 21h15a1.5 1.5 0 001.5-1.5v-15A1.5 1.5 0 0019.5 3zm-1.5 13.5h-4.5v-4.5H18v4.5zm0-6H13.5V6H18v4.5zM6 13.5h4.5V18H6v-4.5zm0-6h4.5v4.5H6V7.5z"/>
                </svg>
                <span class="logo-text">TAS</span>
            <div class="footer-links">
                <a href="#privacy">Privacidad</a>
                <a href="#terms">Términos</a>
                <a href="#contact">Contacto</a>
            </div>
            <div class="social-icons">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
                <a href="#"><i class="fab fa-facebook"></i></a>
            </div>
        </div>
        <p>&copy; 2024 TAS. Todos los derechos reservados.</p>
    </footer>

    <button id="scroll-to-top" title="Volver arriba">↑</button>

    <script src="../js/landing.js"></script>
</body>
</html>