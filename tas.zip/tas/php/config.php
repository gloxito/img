<?php
$host = 'localhost'; 
$usuario = 'root';   
$contraseña = '';    
$bd = 'tas';
$puerto = '3306'; 


$conexion = new mysqli($host, $usuario, $contraseña, $bd, $puerto);
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
echo "Conexión exitosa!";
?>
