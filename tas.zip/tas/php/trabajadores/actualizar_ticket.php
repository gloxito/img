<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['trabajador_id'])) {
    header('Location: ../../html/trabajador.php'); // Redirigir al login
    exit();
}

// Incluir archivo de configuración para la conexión a la base de datos
include '../config.php'; 

// Verifica si la solicitud es POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener el ID de la incidencia y el nuevo estado
    $id_incidencia = $_POST['id_incidencia']; // ID de la incidencia
    $nuevo_estado = $_POST['estado']; // 'abierta', 'en progreso', 'cerrada'

    // Validamos que el estado sea uno de los valores permitidos
    if (in_array($nuevo_estado, ['abierta', 'en progreso', 'cerrada'])) {
        // Consulta para actualizar el estado de la incidencia
        $sql = "UPDATE incidencias SET estado = ?, fecha_actualizacion = NOW() WHERE id_incidencia = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("si", $nuevo_estado, $id_incidencia);

        // Ejecutar la actualización
        if ($stmt->execute()) {
            echo "El estado de la incidencia se ha actualizado correctamente.";
        } else {
            echo "Error al actualizar el estado de la incidencia.";
        }
    } else {
        echo "Estado inválido.";
    }
}
?>

