<?php
session_start();

if (!isset($_SESSION['trabajador_id'])) {
    header('Location: ../../html/trabajador.php');
    exit();
}

include '../config.php';

$trabajador_id = $_SESSION['trabajador_id'];
$sql_trabajador = "SELECT nombre FROM trabajadores WHERE id_trabajador = ?";
$stmt_trabajador = $conexion->prepare($sql_trabajador);
$stmt_trabajador->bind_param("i", $trabajador_id);
$stmt_trabajador->execute();
$result_trabajador = $stmt_trabajador->get_result();
$trabajador_name = $result_trabajador->num_rows > 0 ? $result_trabajador->fetch_assoc()['nombre'] : 'Trabajador no encontrado';

$sql_tickets = "SELECT i.id_incidencia, i.titulo, i.estado, i.fecha_creacion, u.nombre AS usuario 
                FROM incidencias i 
                INNER JOIN usuarios u ON i.id_usuario = u.id_usuario 
                ORDER BY i.fecha_creacion DESC";
$stmt_tickets = $conexion->prepare($sql_tickets);
$stmt_tickets->execute();
$result_tickets = $stmt_tickets->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>TAS - Dashboard de Trabajadores</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="../../css/trabajador_dashboard.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <svg class="logo-icon" viewBox="0 0 24 24" style="width: 24px; height: 24px; fill: #007bff; margin-right: 5px;">
                    <path d="M19.5 3h-15A1.5 1.5 0 003 4.5v15A1.5 1.5 0 004.5 21h15a1.5 1.5 0 001.5-1.5v-15A1.5 1.5 0 0019.5 3zm-1.5 13.5h-4.5v-4.5H18v4.5zm0-6H13.5V6H18v4.5zM6 13.5h4.5V18H6v-4.5zm0-6h4.5v4.5H6V7.5z"/>
                </svg>
                <span style="font-size: 18px; font-weight: bold;">TAS</span>
            </a>
            <div class="navbar-nav ml-auto d-flex align-items-center">
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown">
                        <i class="fas fa-user mr-2"></i><?php echo htmlspecialchars($trabajador_name); ?>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="perfil_trabajador.php"><i class="fas fa-cog mr-2"></i>Perfil</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt mr-2"></i>Cerrar sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-5 pt-3">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Menú</span>
                        <i class="fas fa-bars"></i>
                    </h6>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="trabajador_dashboard.php">
                                <i class="fas fa-ticket-alt mr-2"></i>Incidencias
                            </a>
                            <a class="nav-link active" href="tickets.php">
                                <i class="fas fa-ticket-alt mr-2"></i>Gestión de Tickets
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Contenido Principal -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Dashboard de Trabajadores</h1>
                </div>

                <!-- Tabla de Incidencias -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4>Tickets Creados por Usuarios</h4>
                    <button class="btn btn-sm btn-outline-primary" onclick="location.reload();">
                        <i class="fas fa-sync-alt"></i> Actualizar
                    </button>
                </div>
                <div class="table-responsive">
                    <table id="tabla-tickets" class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Título</th>
                                <th>Usuario</th>
                                <th>Estado</th>
                                <th>Fecha de Creación</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($ticket = $result_tickets->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($ticket['id_incidencia']); ?></td>
                                <td><?php echo htmlspecialchars($ticket['titulo']); ?></td>
                                <td><?php echo htmlspecialchars($ticket['usuario']); ?></td>
                                <td>
                                    <?php
                                    $estado = $ticket['estado'];
                                    $badgeClass = '';
                                    switch ($estado) {
                                        case 'abierta': $badgeClass = 'badge-danger'; break;
                                        case 'en progreso': $badgeClass = 'badge-warning'; break;
                                        case 'cerrada': $badgeClass = 'badge-success'; break;
                                    }
                                    ?>
                                    <span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($estado); ?></span>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($ticket['fecha_creacion'])); ?></td>
                                <td>
                                    <a href="ver_incidencia.php?ticket_id=<?php echo $ticket['id_incidencia']; ?>" class="btn btn-sm btn-outline-info">
                                        <i class="fas fa-eye"></i> Ver
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php
$stmt_trabajador->close();
$stmt_tickets->close();
$conexion->close();
?>