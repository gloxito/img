<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['login'])) {
        // Inicio de sesión
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Consulta para verificar el usuario
        $sql = "SELECT * FROM trabajadores WHERE email='$email'";
        $result = $conexion->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();  // Obtener los datos del trabajador

            // Verificar la contraseña
            if (password_verify($password, $user['contraseña'])) {
                // Inicio de sesión exitoso, se guarda la sesión
                session_start();
                $_SESSION['trabajador_id'] = $user['id_trabajador'];  // Almacenar el ID
                $_SESSION['nombre'] = $user['nombre'];  // Almacenar el nombre

                // Redirigir al Dashboard
                header('Location: trabajador_dashboard.php');
                exit();  // Asegura que el script se detenga después de redirigir
            } else {
                echo "Contraseña incorrecta.";
            }
        } else {
            echo "El usuario no existe.";
        }
    }
}
?>
