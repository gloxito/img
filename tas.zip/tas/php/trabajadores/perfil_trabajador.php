<?php
session_start();

// Verificar sesión activa
if (!isset($_SESSION['trabajador_id'])) {
    header('Location: ../../html/trabajador.php'); // Cambiar al nombre correcto de tu página de inicio de sesión
    exit();
}

include '../config.php'; // Conexión a la base de datos

// Obtener datos del usuario
$user_id = $_SESSION['trabajador_id'];
$sql_user = "SELECT nombre, apellido, email FROM trabajadores WHERE id_trabajador = ?";
$stmt_user = $conexion->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
if ($result_user->num_rows > 0) {
    $user_data = $result_user->fetch_assoc();
    // Asignar el nombre del trabajador a la variable
    $trabajador_name = $user_data['nombre']; // Concatenar nombre y apellido
} else {
    die("Usuario no encontrado.");
}

// Procesar cambio de contraseña
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validar campos
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "Todos los campos son obligatorios.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Las contraseñas no coinciden.";
    } else {
        // Verificar contraseña actual
        $sql_password = "SELECT contraseña FROM trabajadores WHERE id_trabajador = ?";
        $stmt_password = $conexion->prepare($sql_password);
        $stmt_password->bind_param("i", $user_id);
        $stmt_password->execute();
        $result_password = $stmt_password->get_result();
        $user_password_data = $result_password->fetch_assoc();

        if (!password_verify($current_password, $user_password_data['contraseña'])) {
            $error = "La contraseña actual es incorrecta.";
        } else {
            // Actualizar contraseña
            $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $sql_update = "UPDATE trabajadores SET contraseña = ? WHERE id_trabajador = ?";
            $stmt_update = $conexion->prepare($sql_update);
            $stmt_update->bind_param("si", $new_password_hashed, $user_id);

            if ($stmt_update->execute()) {
                $success = "La contraseña ha sido actualizada exitosamente.";
            } else {
                $error = "Error al actualizar la contraseña. Inténtalo de nuevo.";
            }
        }
    }
}

$stmt_user->close();
$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" href="../../css/user_dashboard.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <svg class="logo-icon" viewBox="0 0 24 24" style="width: 24px; height: 24px; fill: #007bff; margin-right: 5px;">
                    <path d="M19.5 3h-15A1.5 1.5 0 003 4.5v15A1.5 1.5 0 004.5 21h15a1.5 1.5 0 001.5-1.5v-15A1.5 1.5 0 0019.5 3zm-1.5 13.5h-4.5v-4.5H18v4.5zm0-6H13.5V6H18v4.5zM6 13.5h4.5V18H6v-4.5zm0-6h4.5v4.5H6V7.5z"/>
                </svg>
                <span style="font-size: 18px; font-weight: bold;">TAS</span>
            </a>
            <div class="navbar-nav ml-auto d-flex align-items-center">
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown">
                        <i class="fas fa-user mr-2"></i><?php echo htmlspecialchars($trabajador_name); ?>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="trabajador_dashboard.php"><i class="fas fa-arrow-left mr-2"></i>Volver</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt mr-2"></i>Cerrar sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Perfil de Trabajador</h1>

        <!-- Mostrar datos del usuario -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Información del Trabajador</h5>
                <p><strong>Nombre:</strong> <?php echo htmlspecialchars($user_data['nombre']); ?></p>
                <p><strong>Apellido:</strong> <?php echo htmlspecialchars($user_data['apellido']); ?></p>
                <p><strong>Correo:</strong> <?php echo htmlspecialchars($user_data['email']); ?></p>
            </div>
        </div>

        <!-- Formulario para cambiar contraseña -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Cambiar Contraseña</h5>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <?php if (isset($success)): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="form-group">
                        <label for="current_password">Contraseña Actual</label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Nueva Contraseña</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirmar Nueva Contraseña</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-primary">Actualizar Contraseña</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
