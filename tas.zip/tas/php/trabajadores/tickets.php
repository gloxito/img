<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['trabajador_id'])) {
    header('Location: ../../html/trabajador.php'); // Redirigir al login
    exit();
}

// Incluir archivo de configuración para la conexión a la base de datos
include '../config.php'; 

// Obtener el nombre del trabajador
$trabajador_id = $_SESSION['trabajador_id'];
$sql_trabajador = "SELECT nombre FROM trabajadores WHERE id_trabajador = ?";
$stmt_trabajador = $conexion->prepare($sql_trabajador);
$stmt_trabajador->bind_param("i", $trabajador_id);
$stmt_trabajador->execute();
$result_trabajador = $stmt_trabajador->get_result();

$trabajador_name = '';
if ($result_trabajador->num_rows > 0) {
    $row_trabajador = $result_trabajador->fetch_assoc();
    $trabajador_name = $row_trabajador['nombre'];
} else {
    $trabajador_name = 'Trabajador no encontrado';
}

// Manejo de la actualización de estado del ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (isset($data['id']) && isset($data['estado'])) {
        $id_incidencia = (int) $data['id'];
        $estado = $conexion->real_escape_string($data['estado']);
        $estados_validos = ['abierta', 'en progreso', 'cerrada'];
        
        if (in_array($estado, $estados_validos)) {
            $sql = "UPDATE incidencias SET estado = '$estado' WHERE id_incidencia = $id_incidencia";
            if ($conexion->query($sql) === TRUE) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => $conexion->error]);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Estado no válido']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Datos inválidos']);
    }
    exit;
}

// Consulta de tickets
$sql = "SELECT * FROM incidencias";
$result = $conexion->query($sql);
$tickets = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $tickets[] = $row;
    }
}
$conexion->close();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablero de Tickets</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="../../css/trabajador_dashboard.css">
    <style>
        /* Estilos del tablero Kanban */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
        .kanban-board {
            display: flex;
            justify-content: space-around;
            margin: 20px;
        }
        .kanban-column {
            width: 30%;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            min-height: 400px;
            padding: 10px;
        }
        .kanban-column h3 {
            text-align: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            margin: 0;
            border-radius: 5px 5px 0 0;
        }
        .kanban-column .ticket-list {
            min-height: 200px;
            padding: 10px;
            overflow-y: auto;
        }
        .ticket {
            background-color: #f4f4f4;
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }
        .ticket small {
            display: block;
            margin-top: 5px;
            font-size: 0.9em;
            color: #555;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <svg class="logo-icon" viewBox="0 0 24 24" style="width: 24px; height: 24px; fill: #007bff; margin-right: 5px;">
                    <path d="M19.5 3h-15A1.5 1.5 0 003 4.5v15A1.5 1.5 0 004.5 21h15a1.5 1.5 0 001.5-1.5v-15A1.5 1.5 0 0019.5 3zm-1.5 13.5h-4.5v-4.5H18v4.5zm0-6H13.5V6H18v4.5zM6 13.5h4.5V18H6v-4.5zm0-6h4.5v4.5H6V7.5z"/>
                </svg>
                <span style="font-size: 18px; font-weight: bold;">TAS</span>
            </a>
            <div class="navbar-nav ml-auto d-flex align-items-center">
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown">
                        <i class="fas fa-user mr-2"></i><?php echo htmlspecialchars($trabajador_name); ?>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="perfil_trabajador.php"><i class="fas fa-cog mr-2"></i>Perfil</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt mr-2"></i>Cerrar sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-5 pt-3">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Menú</span>
                        <i class="fas fa-bars"></i>
                    </h6>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="trabajador_dashboard.php">
                                <i class="fas fa-ticket-alt mr-2"></i>Incidencias
                            </a>
                            <a class="nav-link active" href="tickets.php">
                                <i class="fas fa-ticket-alt mr-2"></i>Gestión de Tickets
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Contenido Principal -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Gestion de Tickets</h1>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
        <?php
        $columnas = [
            'abierta' => 'Abierto',
            'en progreso' => 'En Progreso',
            'cerrada' => 'Cerrado'
        ];

        foreach ($columnas as $estado => $titulo): ?>
            <div class="kanban-column">
                <h3><?= $titulo ?></h3>
                <div class="ticket-list" id="<?= $estado ?>">
                    <?php foreach ($tickets as $ticket): 
                        if ($ticket['estado'] === $estado): ?>
                            <div class="ticket" data-id="<?= $ticket['id_incidencia'] ?>">
                                <strong><?= htmlspecialchars($ticket['titulo']) ?></strong>
                                <p><?= htmlspecialchars($ticket['descripcion']) ?></p>
                            </div>
                        <?php endif;
                    endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', (event) => {
        const tickets = document.querySelectorAll('.ticket');
        const columns = document.querySelectorAll('.ticket-list');

        tickets.forEach(ticket => {
            ticket.setAttribute('draggable', true);
            ticket.addEventListener('dragstart', dragStart);
            ticket.addEventListener('dragend', dragEnd);
        });

        columns.forEach(column => {
            column.addEventListener('dragover', dragOver);
            column.addEventListener('dragenter', dragEnter);
            column.addEventListener('dragleave', dragLeave);
            column.addEventListener('drop', drop);
        });

        function dragStart(e) {
            e.dataTransfer.setData('text/plain', e.target.getAttribute('data-id'));
            setTimeout(() => {
                e.target.style.display = 'none';
            }, 0);
        }

        function dragEnd(e) {
            e.target.style.display = 'block';
        }

        function dragOver(e) {
            e.preventDefault();
        }

        function dragEnter(e) {
            e.preventDefault();
            e.target.classList.add('drag-over');
        }

        function dragLeave(e) {
            e.target.classList.remove('drag-over');
        }

        function drop(e) {
            e.preventDefault();
            const id = e.dataTransfer.getData('text');
            const draggableElement = document.querySelector(`[data-id="${id}"]`);
            const dropzone = e.target.closest('.ticket-list');
            dropzone.appendChild(draggableElement);
            e.target.classList.remove('drag-over');

            updateTicketStatus(id, dropzone.id);
        }

        function updateTicketStatus(id, nuevoEstado) {
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ id: id, estado: nuevoEstado })
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    console.error('Error al actualizar el estado:', data.error);
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        }
    });
    </script>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
