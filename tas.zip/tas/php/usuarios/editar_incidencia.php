<?php
// Incluimos la configuración y la conexión a la base de datos
include '../config.php';
session_start();

// Verificamos si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../html/ybtva-ertvfgre.php');
    exit();
}

// Verificamos si se ha pasado un ticket_id en la URL
if (isset($_GET['ticket_id'])) {
    $ticket_id = $_GET['ticket_id'];
} else {
    header('Location: user_dashboard.php'); // Redirigir si no hay ticket_id
    exit();
}

// Obtener el ID del usuario logueado
$user_id = $_SESSION['user_id'];

// Consulta para obtener los detalles del ticket
$sql = "SELECT * FROM incidencias WHERE id_incidencia = ? AND id_usuario = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ii", $ticket_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header('Location: user_dashboard.php'); // Redirigir si no se encuentra la incidencia
    exit();
}

$ticket = $result->fetch_assoc();

// Cerrar las consultas
$stmt->close();
$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Incidencia</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .form-title {
            text-align: center;
            margin-bottom: 20px;
        }
        .btn-group {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="form-title">Editar Incidencia</h2>
    
    <form method="POST" action="editar_ticket.php">
        <input type="hidden" name="ticket_id" value="<?php echo $ticket['id_incidencia']; ?>">

        <!-- Campo para el Título del Ticket -->
        <div class="form-group">
            <label for="ticketTitle">Título del Ticket</label>
            <input type="text" class="form-control" id="ticketTitle" name="ticketTitle" value="<?php echo htmlspecialchars($ticket['titulo']); ?>" required>
        </div>

        <!-- Campo para la Descripción del Ticket -->
        <div class="form-group">
            <label for="ticketDescription">Descripción</label>
            <textarea class="form-control" id="ticketDescription" name="ticketDescription" rows="4" required><?php echo htmlspecialchars($ticket['descripcion']); ?></textarea>
        </div>

        <!-- Campo para la Prioridad del Ticket -->
        <div class="form-group">
            <label for="ticketPriority">Prioridad</label>
            <select class="form-control" id="ticketPriority" name="ticketPriority" required>
                <option value="baja" <?php echo ($ticket['prioridad'] == 'baja') ? 'selected' : ''; ?>>Baja</option>
                <option value="media" <?php echo ($ticket['prioridad'] == 'media') ? 'selected' : ''; ?>>Media</option>
                <option value="alta" <?php echo ($ticket['prioridad'] == 'alta') ? 'selected' : ''; ?>>Alta</option>
            </select>
        </div>

        <!-- Botones: Actualizar y Volver -->
        <div class="btn-group">
            <!-- Botón Actualizar Incidencia -->
            <button type="submit" class="btn btn-primary flex-grow-1">
                Actualizar Incidencia
            </button>

            <!-- Botón Volver al Dashboard -->
            <a href="user_dashboard.php" class="btn btn-danger flex-grow-1">
                Volver
            </a>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
