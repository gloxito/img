<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    // Si no está logueado, redirigir al login
    header('Location: ../../html/ybtva-ertvfgre.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Ticket</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .form-title {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="form-title">Crear Nuevo Ticket</h2>
    
    <form action="nuevo_ticket.php" method="POST">
    <!-- Campo para el Título del Ticket -->
    <div class="form-group">
        <label for="ticketTitle">Título del Ticket</label>
        <input type="text" class="form-control" id="ticketTitle" name="ticketTitle" required placeholder="Escribe el título del ticket">
    </div>

    <!-- Campo para la Descripción del Ticket -->
    <div class="form-group">
        <label for="ticketDescription">Descripción</label>
        <textarea class="form-control" id="ticketDescription" name="ticketDescription" required placeholder="Describe tu problema o solicitud" rows="4"></textarea>
    </div>

    <!-- Campo para la Prioridad del Ticket -->
    <div class="form-group">
        <label for="ticketPriority">Prioridad</label>
        <select class="form-control" id="ticketPriority" name="ticketPriority" required>
            <option value="baja">Baja</option>
            <option value="media">Media</option>
            <option value="alta">Alta</option>
        </select>
    </div>

    <!-- Campo para la Categoría del Ticket -->
    <div class="form-group">
        <label for="ticketCategory">Categoría</label>
        <select class="form-control" id="ticketCategory" name="ticketCategory" required>
            <option value="problema-tecnico">Problema Técnico</option>
            <option value="solicitud-soporte">Solicitud de Soporte</option>
            <option value="otro">Otro</option>
        </select>
    </div>

    <div class="d-flex">
        <!-- Botón Crear Ticket (envía el formulario) -->
        <button type="submit" class="btn btn-primary flex-grow-1 mr-2">
            <i class="fas fa-plus mr-2"></i>Crear Ticket
        </button>

        <!-- Botón Volver -->
        <a href="user_dashboard.php" class="btn btn-danger flex-grow-1">
            <i class="fas fa-sign-out-alt mr-2"></i>Volver
        </a>
    </div>
</form>

</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html><?php
include '../config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../html/ybtva-ertvfgre.html');
    exit();
}

$titulo = $_POST['ticketTitle'];
$descripcion = $_POST['ticketDescription'];
$prioridad = $_POST['ticketPriority'];
$categoria = $_POST['ticketCategory'];
$id_usuario = $_SESSION['user_id']; 

$fecha_creacion = date('Y-m-d H:i:s');

// Primero obtenemos el id_tematica de la categoría seleccionada
$query = "SELECT id_tematica FROM categorias WHERE nombre_categoria = ?";
$stmt_categoria = $conexion->prepare($query);
$stmt_categoria->bind_param("s", $categoria);
$stmt_categoria->execute();
$result = $stmt_categoria->get_result();
$category_row = $result->fetch_assoc();
$id_tematica = $category_row['id_tematica'] ?? NULL;

// Ahora preparamos la sentencia SQL para insertar la incidencia
$sql = "INSERT INTO incidencias (titulo, descripcion, fecha_creacion, estado, prioridad, id_usuario, id_tematica)
        VALUES (?, ?, ?, 'abierta', ?, ?, ?)";
$stmt = $conexion->prepare($sql);

// Verificamos si la preparación fue exitosa
if ($stmt === false) {
    die('Error al preparar la consulta: ' . $conexion->error);
}

// Vinculamos los parámetros a la declaración preparada
$stmt->bind_param("ssssii", $titulo, $descripcion, $fecha_creacion, $prioridad, $id_usuario, $id_tematica);

// Ejecutamos la consulta
if ($stmt->execute()) {
    echo "Incidencia guardada exitosamente.";
    header("Location: usuario-ticket.php");
} else {
    echo "Error al guardar incidencia: " . $stmt->error;
}

// Cerramos la declaración y la conexión
$stmt->close();
$conexion->close();
?>