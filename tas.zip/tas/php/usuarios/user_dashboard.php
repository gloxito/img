<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../html/ybtva-ertvfgre.php'); // Redirigir al login
    exit();
}
if (isset($_SESSION['ticket_success'])) {
    echo "<div class='alert alert-success'>Ticket creado con éxito.</div>";
    unset($_SESSION['ticket_success']);
}
include '../config.php'; // Incluir la configuración de conexión a la base de datos

// Obtener el nombre del usuario logueado
$user_id = $_SESSION['user_id']; // ID del usuario logueado
$sql_user = "SELECT nombre FROM usuarios WHERE id_usuario = ?"; 
$stmt_user = $conexion->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();

// Obtener el nombre del usuario
$user_name = '';
if ($result_user->num_rows > 0) {
    $row_user = $result_user->fetch_assoc();
    $user_name = $row_user['nombre']; // Obtener el nombre del usuario
} else {
    $user_name = 'Usuario no encontrado'; // Si no se encuentra el usuario
}

// Consulta para obtener las incidencias
$sql = "SELECT * FROM incidencias WHERE id_usuario = ?"; 
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

// Consulta para obtener los trabajadores en línea (agregamos la columna ultima_actividad)
$sql_trabajadores = "SELECT id_trabajador, nombre, apellido, ultima_actividad FROM trabajadores WHERE estado = 'activo'";
$stmt_trabajadores = $conexion->prepare($sql_trabajadores);
$stmt_trabajadores->execute();
$result_trabajadores = $stmt_trabajadores->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>TAS - Dashboard de Gestión de Incidencias</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
    <link rel="stylesheet" href="../../css/user_dashboard.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">TAS</a>
            <div class="navbar-nav ml-auto d-flex align-items-center">
                <button class="btn btn-primary mr-3" onclick="window.location.href='usuario-ticket.php'">
                    <i class="fas fa-plus mr-2"></i>Nueva Incidencia
                </button>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown">
                        <i class="fas fa-user mr-2"></i><?php echo htmlspecialchars($user_name); ?>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="perfil_usuario.php"><i class="fas fa-cog mr-2"></i>Perfil</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt mr-2"></i>Cerrar sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-5 pt-3">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Gestores en Línea</span>
                        <i class="fas fa-users"></i>
                    </h6>

                    <!-- Tarjetas de trabajadores en línea -->
                    <div class="user-cards">
                    <?php
                    // Mostrar trabajadores activos
                    while ($trabajador = $result_trabajadores->fetch_assoc()) {
                        // Comprobar si 'ultima_actividad' está definida antes de usarla
                        $is_active = false;
                        if (isset($trabajador['ultima_actividad'])) {
                            $is_active = (strtotime($trabajador['ultima_actividad']) > strtotime('-5 minutes')); // Verificar si está activo en los últimos 5 minutos
                        }
                    ?>
                        <div class="user-card">
                            <img src="../../assets/<?php echo strtolower($trabajador['nombre']) . ".jpg"; ?>" alt="<?php echo $trabajador['nombre'] . " " . $trabajador['apellido']; ?>" class="user-avatar">
                            <div class="user-info">
                                <h6><?php echo $trabajador['nombre'] . " " . $trabajador['apellido']; ?></h6>
                                <?php if ($is_active): ?>
                                    <!-- Mostrar el punto verde si está activo -->
                                    <span class="status-indicator active"></span>
                                <?php else: ?>
                                    <!-- Mostrar el punto gris si no está activo -->
                                    <span class="status-indicator inactive"></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php } ?>
                    </div>
                </div>
            </nav>

            <!-- Contenido Principal -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Gestión de Incidencias</h1>
                </div>

                <div class="table-responsive">
                    <table id="tabla-incidencias" class="table table-hover">
                        <thead>
                            <tr>
                                <th>Incidencia</th>
                                <th>Estado</th>
                                <th>Fecha</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $result->fetch_assoc()) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['titulo']); ?></td>
                                    <td>
                                        <?php
                                        $estado = $row['estado'];
                                        $badgeClass = '';
                                        switch ($estado) {
                                            case 'abierta':
                                                $badgeClass = 'badge-danger';
                                                break;
                                            case 'en progreso':
                                                $badgeClass = 'badge-warning';
                                                break;
                                            case 'cerrada':
                                                $badgeClass = 'badge-success';
                                                break;
                                        }
                                        ?>
                                        <span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($estado); ?></span>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($row['fecha_creacion'])); ?></td>
                                    <td>
                                        <a href="ver_incidencia.php?ticket_id=<?php echo htmlspecialchars($row['id_incidencia']); ?>" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                        <a href="editar_incidencia.php?ticket_id=<?php echo htmlspecialchars($row['id_incidencia']); ?>" class="btn btn-sm btn-outline-secondary">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!-- Aquí agregamos el script JavaScript -->
    <script src="../../js/user_dashboard.js"></script>
</body>
</html>

<?php
// Cerrar las conexiones
$stmt->close();
$stmt_user->close();
$stmt_trabajadores->close();
$conexion->close();
?>
