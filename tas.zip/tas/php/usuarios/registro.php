<?php
include '../config.php'; // Archivo de conexión a la base de datos

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Capturar los datos enviados desde el formulario
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hashear la contraseña

    // Obtener la fecha actual
    $fecha_registro = date('Y-m-d'); // Formato de fecha: 'YYYY-MM-DD'

    // Verificar si el email ya existe
    $checkEmail = "SELECT * FROM Usuarios WHERE email=?";
    $stmt = $conexion->prepare($checkEmail);
    $stmt->bind_param("s", $email); // "s" indica que $email es una cadena
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Este correo electrónico ya está registrado.";
    } else {
        // Insertar el usuario en la base de datos
        $sql = "INSERT INTO Usuarios (nombre, apellido, email, contraseña, fecha_registro) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("sssss", $nombre, $apellido, $email, $password, $fecha_registro);

        if ($stmt->execute()) {
            echo "Registro exitoso. Ahora puedes iniciar sesión.";
        } else {
            echo "Error en el registro: " . $stmt->error;
        }
    }

    $stmt->close(); // Cerrar la declaración preparada
    $conexion->close(); // Cerrar la conexión
}
?>
